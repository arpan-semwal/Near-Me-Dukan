/* eslint-disable no-mixed-spaces-and-tabs */

import Navbar from "../../components/Navbar/Navbar"
import Panel from "../../components/Panel/Panel"

 

export default function HomePage() {
  return (
	<div>
	   <div>
		 <Navbar/>
		 <Panel/>
	   </div>
	</div>
  )
}
